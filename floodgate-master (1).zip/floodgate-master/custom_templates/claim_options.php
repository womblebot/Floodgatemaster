<!-- Claim options. You can leave this file blank, or add form elements for customizing the claim page. -->
<input type="checkbox" name="miner" id="co_miner"/><label for="co_miner">Allow the site to mine on one thread with 80% idle time (increases payouts by 5%)</label>
<br/><input type="checkbox" name="some_other_key" id="co_some_other_key"/><label id="co_some_other_key">Some other option</label>
<br/><input type="checkbox" name="another_key" id="co_another_key"/><label id="co_another_key">Another option</label>
