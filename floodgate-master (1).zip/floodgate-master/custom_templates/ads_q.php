<!-- Put some ad units here -->
<!-- Yes, this file can be the same as ads.i.php. -->

<!-- geekbasic's blkads. Just replace the BLK address in the URL with yours! -->
<iframe sandbox="allow-forms allow-scripts" src="http://www.geekbasic.com/blkads/index.php?r=B6q6aympDZyasX5TZsxxBqmWhxtu2iNen7" style="display:block;margin-left:auto;margin-right:auto;height:90px;width:728px" scrolling="no"></iframe>
