<nav class="navbar">
<a href="http://example.com">some site</a>
<a href="http://example.com">another site</a>
<a href="http://example.com">you get the idea</a>
</nav>
