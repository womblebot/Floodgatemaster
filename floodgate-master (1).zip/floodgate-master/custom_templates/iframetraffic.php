<!-- Perhaps someone wants to pay you for traffic? Just put their URL in an iframe here! -->
<center>
<iframe style="display:block;height:90px;width:720px" src="http://example.com"></iframe>
<iframe style="display:block;height:90px;width:720px" src="http://example.com"></iframe>
</center>
